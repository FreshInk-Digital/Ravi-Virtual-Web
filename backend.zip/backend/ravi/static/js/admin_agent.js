(function($) {
    $(document).ready(function() {
        // Get the region, district, and township fields
        const regionField = $('#id_region');
        const districtField = $('#id_district');
        const townshipField = $('#id_township');

        // Define district and township choices for each region
        const districtChoices = {
            Dodoma: {
                Kondoa: ['Bolisa', 'Chemchem', 'Kilimani', 'Kingale', 'Kolo', 'Kondoa Mjini', 'Serya', 'Suruke'],
                Chemba: ['Babayu', 'Chandama', 'Chemba', 'Churuku'],
                'Dodoma Urban': ['Chali', 'Chibelela', 'Chifutuka', 'Chikola', 'Chipanga', 'Ibihwa'],
            },
            Temeke: {
                Ilala: ['Buguruni', 'Buyuni', 'Chanika', 'Gerezani'],
                Ubungo: ['Goba', 'Kibamba', 'Kimara', 'Kwembe'],
            },
            Arusha: {
                Meru: ['Akheri', 'Ambureni', 'Imbaseni', 'Kikatiti', 'Kikwe'],
                Longido: ['Namanga', 'Noondoto', 'Olmolog', 'Orbomba', 'Sinya', 'Tingatinga'],
            },
        };

        // Function to populate district dropdown based on selected region
        function updateDistrictOptions() {
            const selectedRegion = regionField.val(); // Get the selected region
            const districts = districtChoices[selectedRegion] || {}; // Get the districts for the region

            districtField.empty(); // Clear the current district options
            districtField.append(new Option('---------', '')); // Add a default empty option

            // Add new district options
            Object.keys(districts).forEach(district => {
                districtField.append(new Option(district, district));
            });

            // Trigger update for township dropdown
            updateTownshipOptions();
        }

        // Function to populate township dropdown based on selected district
        function updateTownshipOptions() {
            const selectedRegion = regionField.val(); // Get the selected region
            const selectedDistrict = districtField.val(); // Get the selected district
            const townships = (districtChoices[selectedRegion] || {})[selectedDistrict] || []; // Get the townships for the district

            townshipField.empty(); // Clear the current township options
            townshipField.append(new Option('---------', '')); // Add a default empty option

            // Add new township options
            townships.forEach(township => {
                townshipField.append(new Option(township, township));
            });
        }

        // Update districts when the region changes
        regionField.change(updateDistrictOptions);

        // Update townships when the district changes
        districtField.change(updateTownshipOptions);

        // Initialize dropdowns on page load (useful for editing existing records)
        updateDistrictOptions();
    });
})(django.jQuery);
