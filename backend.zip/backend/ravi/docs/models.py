from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class BookCategory(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return (self.name)
    
    class Meta:
        verbose_name_plural = "BookCategory"


class Book(models.Model):    
    book = models.FileField(upload_to='attachments/', blank=True, null=True)
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    date_created = models.DateTimeField(auto_now_add=True)
    last_update = models.DateTimeField(auto_now_add=True)
    category = models.ForeignKey(BookCategory, on_delete=models.CASCADE, related_name="books")
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="books")

    SENSITIVITY_CHOICES = [
        ('critical', 'critical'),
        ('not_critical', 'Not Critical'),
    ]
    sensitivity = models.CharField(max_length=20, choices=SENSITIVITY_CHOICES, default='not_critical')
    
    def __str__(self):
        return (self.name)
    
class Publication(models.Model):
    publication = models.FileField(upload_to='attachments/', blank=True, null=True)
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    date_created = models.DateTimeField(auto_now_add=True)
    last_update = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="publications")

    def __str__(self):
        return (self.name)
    
    
class Messages(models.Model):
    URGENT = 'URGENT'
    NORMAL = 'NORMAL'
    NOT_URGENT = 'NOT URGENT'

    STATUS_CHOICES = [
        (URGENT, 'Urgent'),
        (NORMAL, 'Normal'),
        (NOT_URGENT, 'Not Urgent'),
    ]

    user_name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255 )
    phone = models.CharField(max_length=255, default="")
    agent_name = models.CharField(max_length=255, default="")
    location = models.CharField(max_length=255, default="")
    agent_phone = models.CharField(max_length=255, default="")
    message = models.CharField(max_length=255)
    
    date_created = models.DateTimeField(auto_now_add=True)
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default=NOT_URGENT,
    )

    def __str__(self):
        return self.user_name
    
    class Meta:
        verbose_name_plural = 'Messages'
    

class Cases(models.Model):
    CATEGORY_CHOICES = [
        ('Criminal', 'Criminal'),
        ('Civil', 'Civil'),
        ('Administrative', 'Administrative'),
        ('Othe', 'Other'),
    ]

    name = models.CharField(max_length=255)  # Case name
    description = models.TextField()  # Case description
    date_created = models.DateField(auto_now_add=True)  # Date created
    file_path = models.FileField(upload_to='cases/files/')  # File associated with the case
    category = models.CharField(max_length=14, choices=CATEGORY_CHOICES, default='Other')  # Category

    def __str__(self):
        return self.name


class Agent(models.Model):
    REGION_CHOICES = [
        ('Dodoma', 'Dodoma'),
        ('Temeke', 'Temeke'),
        ('Arusha', 'Arusha'),
    ]
    
    DISTRICT_CHOICES = [
    ('Kondoa', 'Kondoa'),
    ('Chemba', 'Chemba'),
    ('Dodoma Urban', 'Dodoma Urban'),
    ('Bahi', 'Bahi'),
    ('Congwa', 'Congwa'),
    ('Mpwapwa', 'Mpwapwa'),
    ('Chamwino', 'Chamwino'),
    ('Kinondoni', 'Kinondoni'),
    ('Ilala', 'Ilala'),
    ('Ubungo', 'Ubungo'),
    ('Kigamboni', 'Kigamboni'),
    ('Kurasini', 'Kurasini'),
    ('Karatu', 'Karatu'),
    ('Longido', 'Longido'),
    ('Meru', 'Meru'),
    ('Monduli', 'Monduli'),
    ('Ngorongoro', 'Ngorongoro'),
    ]

    TOWNSHIP_CHOICES = [
        ('Bolisa', 'Bolisa') , ('Chemchem', 'Chemchem') , ('Kilimani', 'Kilimani') , ('Kingale', 'Kingale') , ('Kolo', 'Kolo') , ('Kondoa Mjini', 'Kondoa Mjini') , ('Serya', 'Serya') , ('Suruke', 'Suruke'),
        ('Babayu', 'Babayu') , ('Chandama', 'Chandama') , ('Chemba', 'Chemba') , ('Churuku', 'Churuku') ,
        ('Chali', 'Chali') , ('Chibelela', 'Chibelela') , ('Chifutuka', 'Chifutuka') , ('Chikola', 'Chikola') , ('Chipanga', 'Chipanga') , ('Ibihwa', 'Ibihwa') ,
        ('Buguruni', 'Buguruni') , ('Buyuni', 'Buyuni') , ('Chanika', 'Chanika') , ('Gerezani', 'Gerezani') ,
        ('Goba','Goba') , ('Kibamba', 'Kibamba') , ('Kimara', 'Kimara') , ('Kwembe', 'Kwembe') ,
        ('Akheri', 'Akheri') , ('Ambureni', 'Ambureni') , ('Imbaseni', 'Imbaseni') , ('Kikatiti', 'Kikatiti') , ('Kikwe', 'Kikwe') ,
        ('Namanga', 'Namanga') , ('Noondoto', 'Noondoto') , ('Olmolog', 'Olmolog') , ('Orbomba', 'Orbomba') , ('Sinya', 'Sinya') , ('Tingatinga', 'Tingatinga')
    ]
    region = models.CharField(max_length=50, choices=REGION_CHOICES)
    district = models.CharField(max_length=50, choices=DISTRICT_CHOICES)
    township = models.CharField(max_length=50, choices=TOWNSHIP_CHOICES)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15, unique=True)
    email = models.EmailField(unique=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.region} - {self.district})"
